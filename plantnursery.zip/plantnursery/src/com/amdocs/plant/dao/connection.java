package com.amdocs.plant.dao;

import java.sql.Connection;

import java.sql.DriverManager;

public class connection {

	public Connection connect() {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver"); // registration
//			System.out.println("Inside try after class.forname");
			con = DriverManager.getConnection("Jdbc:Oracle:thin:@localhost:1521:orcl", "c##plant", "plant1234"); // connection
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
}
