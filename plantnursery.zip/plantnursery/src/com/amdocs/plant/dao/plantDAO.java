package com.amdocs.plant.dao;

import java.sql.*;
//import com.amdocs.plant.pojo.Plant;
import java.util.ArrayList;
import java.util.List;

import com.amdocs.plant.exception.PlantNurseryException;
import com.amdocs.plant.pojo.Plant;

public class plantDAO {
//insert details
	PreparedStatement pst;
	connection plantconnect = new connection();
	Connection con = plantconnect.connect();

	public int addPlant(Plant pla) {
		String insertSQL = "INSERT INTO plants(plantId,plantName,originCountryName,sunlightRequired,waterSupplyFrequency,plantType,cost) "
				+ "VALUES (plant_seq.NEXTVAL, ?, ?, ?, ?, ?,?)";
		int count = 0;
		try {
			pst = con.prepareStatement(insertSQL);
			pst.setString(1, pla.getPlantName());
			pst.setString(2, pla.getOriginCountryName());
			pst.setBoolean(3, pla.isSunlightRequired());
			pst.setString(4, pla.getWaterSupplyFrequency());
			pst.setString(5, pla.getPlantType());
			pst.setDouble(6, pla.getCost());
			count = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return count;

	}

	public boolean updatePlantCost(int plantId, double cost) throws PlantNurseryException {
		String updateSQL = "UPDATE plants SET cost = ? WHERE plantId = ?";
		int rowsUpdated = 0;
		try {
			pst = con.prepareStatement(updateSQL);
			pst.setDouble(1, cost);
			pst.setInt(2, plantId);
			rowsUpdated = pst.executeUpdate();
			if (rowsUpdated == 0) {
				throw new PlantNurseryException("Plant not found");
			}
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
		return rowsUpdated > 0;
	}
	//

	//
	public int deletePlant(int id) throws PlantNurseryException {
		int rowsDeleted = 0;
		String deleteSQL = "DELETE FROM plants WHERE plantId = ?";
		try {
			pst = con.prepareStatement(deleteSQL);
			pst.setInt(1, id);

			rowsDeleted = pst.executeUpdate();
			if (rowsDeleted == 0) {
				throw new PlantNurseryException("Table does not have given plantId data");
			}
		} catch (Exception e) {
			System.out.println(e);

		}
		return rowsDeleted;
	}

	public List<Plant> showAllPlants() throws PlantNurseryException {
		List<Plant> PlantList = new ArrayList<>();
		String selectSQL = "SELECT * FROM plants ";

		try {
			pst = con.prepareStatement(selectSQL);
			ResultSet resultSet = pst.executeQuery();
			while (resultSet.next()) {
				PlantList.add(new Plant(resultSet.getInt("plantId"), resultSet.getString("plantName"),
						resultSet.getString("originCountryName"), resultSet.getBoolean("sunlightRequired"),
						resultSet.getString("waterSupplyFrequency"), resultSet.getString("plantType"),
						resultSet.getDouble("cost")));
			}
			if (PlantList.size() == 0) {
				throw new PlantNurseryException("we dont have any information in Plant table");
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return PlantList;
	}

	public List<Plant> searchByOriginCountryName(String country) throws PlantNurseryException {
		List<Plant> PlantList = new ArrayList<>();
		String selectSQL = "SELECT * FROM plants WHERE originCountryName = ?";

		try {
			pst = con.prepareStatement(selectSQL);
			pst.setString(1, country);
			ResultSet resultSet = pst.executeQuery();

			while (resultSet.next()) {
				PlantList.add(new Plant(resultSet.getInt("plantId"), resultSet.getString("plantName"),
						resultSet.getString("originCountryName"), resultSet.getBoolean("sunlightRequired"),
						resultSet.getString("waterSupplyFrequency"), resultSet.getString("plantType"),
						resultSet.getDouble("cost")));
			}
			if (PlantList.size() == 0) {
				throw new PlantNurseryException("Plant of having same origin name not Found");
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return PlantList;
	}

	public List<Plant> searchOutdoorPlantsWithSunlight() throws PlantNurseryException {
		List<Plant> PlantList = new ArrayList<>();
		String selectSQL = "SELECT * FROM plants WHERE (plantType = ? AND sunlightRequired = ?)";

		try {
			pst = con.prepareStatement(selectSQL);
			pst.setString(1, "outdoor");
			pst.setInt(2, 1);

			ResultSet resultSet = pst.executeQuery();
			while (resultSet.next()) {
				PlantList.add(new Plant(resultSet.getInt("plantId"), resultSet.getString("plantName"),
						resultSet.getString("originCountryName"), resultSet.getBoolean("sunlightRequired"),
						resultSet.getString("waterSupplyFrequency"), resultSet.getString("plantType"),
						resultSet.getDouble("cost")));
			}
			if (PlantList.size() == 0) {
				throw new PlantNurseryException("Plant table doesn't have outdoor plant with sunlight");

			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return PlantList;
	}

	public int countPlantsByWaterSupplyFrequency(String water) throws PlantNurseryException{
		int count = 0;
		String selectSQL = "SELECT COUNT(*) FROM plants WHERE  waterSupplyFrequency= ?";

		try {
			pst = con.prepareStatement(selectSQL);
			pst.setString(1, water);

			ResultSet resultSet = pst.executeQuery();
			if (resultSet.next()) {
				count = resultSet.getInt(1);
			}
			if(count==0) {
				throw new PlantNurseryException("no plant in database having similar water supply frequency");
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return count;
	}

}
