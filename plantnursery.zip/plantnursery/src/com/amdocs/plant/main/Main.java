package com.amdocs.plant.main;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.amdocs.plant.dao.*;
import com.amdocs.plant.exception.PlantNurseryException;
import com.amdocs.plant.pojo.Plant;
//import com.amdocs.plant.pojo.Plant;

public class Main {

	public static void main(String[] args) throws PlantNurseryException {
		plantDAO plan=new plantDAO();
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("........Welcome to the Nursery Plant management System Console Project!!........");

			
			while (true) {
			    System.out.println("Plant Nursery Management System");
			    System.out.println("1. Add Plant");
			    System.out.println("2. Delete Plant");
			    System.out.println("3. Update Plant Cost");
			    System.out.println("4. Show All Plants");
			    System.out.println("5. search By Origin Country Name of Plants");
			    System.out.println("6. search Outdoor Plants with Sunlight");
			    System.out.println("7. Count plants by water supply frequency ");
			    System.out.println("8. Exit");
			    System.out.print("Enter your choice: ");
			    int choice = sc.nextInt();
			    sc.nextLine(); // Consume the newline character
			    
			    			switch(choice)
			    			{
			    				case 1:
			    					System.out.println("Add new plant");
			    					System.out.println("Enter Plant Id");
			    					int plantId=sc.nextInt();
			    					sc.nextLine();
			    					System.out.println("Enter Plant name");
			    					String plantName=sc.nextLine();
			    					System.out.println("Enter name of a origin country of plants");
			    					String originCountryName=sc.nextLine();
			    					System.out.println("Does the plant require sunlight (true/false)");
			    					boolean sunlightRequired=sc.nextBoolean();
			    					sc.nextLine();
			    					System.out.println("Enter Frequency of water supply (daily/alternateDays/weekly");
			    					String waterSupplyFrequency=sc.nextLine();
			    					System.out.println("Enter type of plant (indoor/outdoor)");
			    					String plantType=sc.nextLine();
			    					System.out.println("Enter cost of plant");
			    					double cost=sc.nextDouble();
			    					Plant pla=new Plant(plantId,plantName,originCountryName,sunlightRequired,waterSupplyFrequency,plantType,cost);
			    					int c=plan.addPlant(pla);
			    					System.out.println(c+"Plant Added Successfully");
			    					break;
			    					
			    				
			    				case 2:
			    					System.out.println("Enter id of plant to delete");
			    					int id=sc.nextInt();
			    					int c1=plan.deletePlant(id);
			    					System.out.println(c1+ "Record deleted");
			    					break;
			    					
			    				case 3:
			    					System.out.println("Enter id of a plant to update the cost");
			    					int plaid=sc.nextInt();
			    					System.out.println("Enter the new Plant cost");
			    					double plaCost=sc.nextDouble();
			    					boolean res=plan.updatePlantCost(plaid, plaCost);
			    					if(res==true)
			    						System.out.println("Plant Cost updated successfully");
			    					else
			    						System.out.println("Plant Cost update failed");
			    					break;
			    				
			    				case 4:
			    					List<Plant> list1=new ArrayList<>();
			    					list1=plan.showAllPlants();
			    					
			                            for (Plant plant : list1) {
			                            	System.out.println(plant.toString());
			                                
			                                System.out.println("-------------------------");
			                            }
			                        
			                        break;						    					
			    				case 5:
			    					System.out.println("Enter origin country name");
			    					String origin=sc.nextLine();
			    					List<Plant> list3=new ArrayList<>();
			    					list3=plan.searchByOriginCountryName(origin);
			    					for (Plant pl2 : list3) {
			    						System.out.println(pl2.toString());
	                                
	                                System.out.println("-------------------------");
		                            }
			    					  break;
			    				
			                        
			    				case 6:
			    					List<Plant> list4=new ArrayList<>();
			    					list4=plan.searchOutdoorPlantsWithSunlight();
			    					
			    					if (list4.isEmpty()) {
			                            System.out.println("No outdoor plants require sunlight.");
			                        } else {
			                            System.out.println("Outdoor plants that require sunlight:");
			                            for (Plant pl3 : list4) {
			                            	System.out.println(pl3.toString());
			                                System.out.println("-------------------------");
			                            }
			                        }
			                        
			                        break;	
			    				case 7:
			    					System.out.println("Enter The water Supply Frequency");
			    					String waterFreq=sc.nextLine();
			    					int c3=plan.countPlantsByWaterSupplyFrequency(waterFreq);
			    					System.out.println(c3+" Number of Plants in "+waterFreq);
			    					break;
			    				
			    				case 8:
			    					System.out.println("Thank you for using this program");
			    					//f=false;
			    					System.exit(0);
			    					break;
			    			}
			    		}
		} 	
            	}

            }

            
