package com.amdocs.plant.exception;

public class PlantNurseryException extends Exception {
	public PlantNurseryException() {
		super();
	}
	public PlantNurseryException(String msg) {
		super(msg);
	}
	
	

}
